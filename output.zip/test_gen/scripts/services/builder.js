(function () {
    'use strict';

    /**
     * @ngdoc service
     * @name app.builderService
     * @description
     * # builderService
     * Factory in the app.
     */
    angular.module('app')
    .factory('builderService', function (apiService) {
       
        var service = {
            'getAll' : getAll,
            'get' : get,
            'add' : add,
            'change' : change,
            'remove' : remove,
            'changeImage' : changeImage,
            
        };
       
        return service;
        
        function getAll() {
            return apiService.get('builders' , {} , {key: 'builder'});
        }

        function get(builder_id) {
            return apiService.get('builders' + '/' + builder_id , {} , {key: 'builders'});
        }

        function add(builder_id, data) {
            return apiService.put('builders' + '/' + builder_id , {builder: data} );
        }

        function change(builder_id, data) {
            return apiService.post('builders' + '/' + builder_id , {builder: data} );
        }

        function remove(builder_id) {
            return apiService.delete('builders' + '/' + builder_id  );
        }

        function changeImage(builder_id, image, data) {
            return apiService.post('builders' + '/' + builder_id + '/' + image , {builder: data} );
        }


    });
})();
