(function () {
    'use strict';

    /**
     * @ngdoc service
     * @name app.deficiencyService
     * @description
     * # deficiencyService
     * Factory in the app.
     */
    angular.module('app')
    .factory('deficiencyService', function (apiService) {
       
        var service = {
            'getAll' : getAll,
            'change' : change,
            'remove' : remove,
            'get' : get,
            'add' : add,
            
        };
       
        return service;
        
        function getAll() {
            return apiService.get('deficiencies' , {} , {key: 'deficiency'});
        }

        function change(data) {
            return apiService.post('deficiencies' , {deficiency: data} );
        }

        function remove(deficiency_id) {
            return apiService.delete('deficiencies' + '/' + deficiency_id  );
        }

        function get(deficiency_id) {
            return apiService.get('deficiencies' + '/' + deficiency_id , {} , {key: 'deficiencies'});
        }

        function add(deficiency_id, data) {
            return apiService.put('deficiencies' + '/' + deficiency_id , {deficiency: data} );
        }


    });
})();
