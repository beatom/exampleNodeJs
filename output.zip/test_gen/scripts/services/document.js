(function () {
    'use strict';

    /**
     * @ngdoc service
     * @name app.documentService
     * @description
     * # documentService
     * Factory in the app.
     */
    angular.module('app')
    .factory('documentService', function (apiService) {
       
        var service = {
            'getAll' : getAll,
            'get' : get,
            'change' : change,
            'remove' : remove,
            'add' : add,
            
        };
       
        return service;
        
        function getAll() {
            return apiService.get('documents' , {} , {key: 'document'});
        }

        function get(document_id) {
            return apiService.get('documents' + '/' + document_id , {} , {key: 'documents'});
        }

        function change(data) {
            return apiService.post('documents' , {document: data} );
        }

        function remove(document_id) {
            return apiService.delete('documents' + '/' + document_id  );
        }

        function add(document_id, data) {
            return apiService.put('documents' + '/' + document_id , {document: data} );
        }


    });
})();
