'use strict';

 angular.module('config', [])

.constant('CONFIG', {name:'local',website:'http://localhost:9000',api:{url:'http://athena.dev.firestitch.com/api/'}})

;